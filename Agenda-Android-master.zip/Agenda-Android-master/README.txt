	PROJETO DE UMA AGENDA SIMPLES DE CONTATO;
             android
:q

